/*1- Ler arquivo ((arquivo aberto, lido e fechado) colocados em uma matriz alocada dinamicamente 12x10
2-salvar ao final
3-Liberar a memoria no final 
4- Se a plateia não existir, preencher as posições com "-"
5- sempre que alterar a matriz plateia, salvar no arquivo// tem que ser a ultima. 

6- todas as entradas devem ser validadas 
7- (sempre com "flush(stdin);" // ler como caractere*/

#include <stdio.h>

void lerArquivo();

void mostrarPlateia();

void mostrarOcupacao();

void venderIngresso();

void cancelarIngresso();


int main()
{
    int op = -1; 
    
    while (op!=0){
        //formatação 
        printf("0-Sair do programa\n1-Mostrar plateia\n2-Mostrar ocupacao\n3-Vender ingresso\n4-Cancelar ingresso (devolucao) ")
        scanf("%d", &op);
        //valida
        switch (op){
            case 0:
                printf("Você optou for encerrar o programa, adeus :c");
                break;
            case 1: 
                mostrarPlateia();
                break;
            case 2:
                mostrarOcupacao();
                break;
            case 3:
                venderIngresso();
                break;
            case 4:
                cancelarIngresso();
                break;
            case default:
                printf("Valor inválido!\nEscolha um novo valor.");
        }
    }
    

    return 0;
}


